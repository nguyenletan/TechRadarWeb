bower-angular-scenario
======================

bower repo for angular-scenario.js