# Contributing to JSON3

If you'd like to contribute to JSON3, please review our [contributing guidelines](http://bestiejs.github.io/json3/#section_5). Thanks!
